# CHANGELOG

## 1.2 - 2022-04-20

This release introduces a compatibility layer with the PSR-20 draft, allowing us to already
get some interoperability by depending on a shared interface.

## 1.1 - 2020-10-04

* The default branch of the GitHub repository has been renamed from `master` to `main` - 
  if you're using `dev-master` as a version constraint in your `composer.json`, please 
  update it to `dev-main`.
* Added PHP 8 forward compatibility

## 1.0.1 - 2019-08-26

- Remove `phpunit/phpunit` from non-dev dependencies.

## 1.0.0 - 2019-08-20

Initial release
